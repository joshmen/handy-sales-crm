
-- ========================================
-- Script de Creación de Tablas Handy ERP (Multi-Tenant)
-- Arquitectura: Shared Database, Shared Schema
-- Base de datos: MySQL
-- ========================================

CREATE TABLE Tenants (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre_empresa VARCHAR(255) NOT NULL,
  rfc VARCHAR(20),
  contacto VARCHAR(255),
  activo BOOLEAN DEFAULT TRUE,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Zonas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT,
  activo BOOLEAN DEFAULT TRUE,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE
);

CREATE TABLE CategoriasClientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT,
  activo BOOLEAN DEFAULT TRUE,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE
);

CREATE TABLE Clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  nombre VARCHAR(255) NOT NULL,
  rfc VARCHAR(13),
  correo VARCHAR(255),
  telefono VARCHAR(20),
  direccion TEXT,
  id_zona INT,
  categoria_cliente_id INT,
  activo BOOLEAN DEFAULT TRUE,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (id_zona) REFERENCES Zonas(id) ON DELETE SET NULL,
  FOREIGN KEY (categoria_cliente_id) REFERENCES CategoriasClientes(id) ON DELETE SET NULL
);

CREATE TABLE FamiliasProductos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT,
  activo BOOLEAN DEFAULT TRUE,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE
);

CREATE TABLE CategoriasProductos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT,
  activo BOOLEAN DEFAULT TRUE,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE
);

CREATE TABLE UnidadesMedida (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  nombre VARCHAR(50) NOT NULL,
  abreviatura VARCHAR(10),
  activo BOOLEAN DEFAULT TRUE,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE
);

CREATE TABLE Productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  nombre VARCHAR(255) NOT NULL,
  codigo_barra VARCHAR(100),
  descripcion TEXT,
  familia_id INT,
  categoria_id INT,
  unidad_medida_id INT,
  precio_base DECIMAL(10,2),
  activo BOOLEAN DEFAULT TRUE,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (familia_id) REFERENCES FamiliasProductos(id) ON DELETE SET NULL,
  FOREIGN KEY (categoria_id) REFERENCES CategoriasProductos(id) ON DELETE SET NULL,
  FOREIGN KEY (unidad_medida_id) REFERENCES UnidadesMedida(id) ON DELETE SET NULL
);

CREATE TABLE Inventario (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  producto_id INT NOT NULL,
  cantidad_actual DECIMAL(10,2),
  stock_minimo DECIMAL(10,2),
  stock_maximo DECIMAL(10,2),
  actualizado_en DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES Productos(id) ON DELETE CASCADE
);

CREATE TABLE ListasPrecios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  nombre VARCHAR(100),
  descripcion TEXT,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE
);

CREATE TABLE PreciosPorProducto (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  producto_id INT,
  lista_precio_id INT,
  precio DECIMAL(10,2),
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES Productos(id) ON DELETE CASCADE,
  FOREIGN KEY (lista_precio_id) REFERENCES ListasPrecios(id) ON DELETE CASCADE
);

CREATE TABLE DescuentosPorCantidad (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  producto_id INT,
  cantidad_minima DECIMAL(10,2),
  descuento_porcentaje DECIMAL(5,2),
  tipo_aplicacion ENUM('Global', 'Producto') DEFAULT 'Producto',
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES Productos(id) ON DELETE CASCADE
);

CREATE TABLE Promociones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  nombre VARCHAR(100),
  descripcion TEXT,
  producto_id INT,
  descuento_porcentaje DECIMAL(5,2),
  fecha_inicio DATE,
  fecha_fin DATE,
  activo BOOLEAN DEFAULT TRUE,
  FOREIGN KEY (tenant_id) REFERENCES Tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES Productos(id) ON DELETE CASCADE
);
