
-- ========================================
-- Seed de datos iniciales para Handy ERP
-- ========================================

-- Tenants
INSERT INTO Tenants (id, nombre_empresa, rfc, contacto) VALUES
(1, 'Distribuidora del Centro', 'DCE010101AAA', 'contacto@centro.com'),
(2, 'Rutas Express Norte', 'REN020202BBB', 'admin@rutasnorte.com');

-- Zonas
INSERT INTO Zonas (tenant_id, nombre, descripcion) VALUES
(1, 'Zona Norte', 'Cobertura región norte'),
(1, 'Zona Sur', 'Cobertura región sur'),
(2, 'Zona Metropolitana', 'Cobertura ciudad capital');

-- Categorías de Clientes
INSERT INTO CategoriasClientes (tenant_id, nombre, descripcion) VALUES
(1, 'Mayorista', 'Cliente con alto volumen'),
(1, 'Minorista', 'Cliente de menudeo'),
(2, 'Frecuente', 'Cliente con visitas programadas');

-- Clientes
INSERT INTO Clientes (tenant_id, nombre, rfc, correo, telefono, direccion, id_zona, categoria_cliente_id) VALUES
(1, 'Comercializadora Gómez', 'CGZ030303CCC', 'ventas@gomez.com', '5511223344', 'Av. Reforma 123', 1, 1),
(1, 'Abarrotes La Esquina', 'ALE040404DDD', 'contacto@laesquina.com', '5544332211', 'Calle 5 #22', 2, 2);

-- Familias de productos
INSERT INTO FamiliasProductos (tenant_id, nombre, descripcion) VALUES
(1, 'Lácteos', 'Productos derivados de leche'),
(1, 'Bebidas', 'Refrescos y jugos');

-- Categorías de productos
INSERT INTO CategoriasProductos (tenant_id, nombre, descripcion) VALUES
(1, 'Refrigerados', 'Necesitan refrigeración'),
(1, 'No perecederos', 'Larga vida útil');

-- Unidades de medida
INSERT INTO UnidadesMedida (tenant_id, nombre, abreviatura) VALUES
(1, 'Litro', 'L'),
(1, 'Pieza', 'PZA');

-- Productos
INSERT INTO Productos (tenant_id, nombre, codigo_barra, descripcion, familia_id, categoria_id, unidad_medida_id, precio_base) VALUES
(1, 'Leche Entera 1L', '7501001234567', 'Leche entera pasteurizada', 1, 1, 1, 18.50),
(1, 'Refresco Cola 600ml', '7502007654321', 'Refresco sabor cola', 2, 2, 1, 12.00);

-- Inventario
INSERT INTO Inventario (tenant_id, producto_id, cantidad_actual, stock_minimo, stock_maximo) VALUES
(1, 1, 500, 50, 1000),
(1, 2, 300, 30, 800);

-- Listas de precios
INSERT INTO ListasPrecios (tenant_id, nombre, descripcion) VALUES
(1, 'Precio Público General', 'Precio estándar para todos los clientes');

-- Precios por producto
INSERT INTO PreciosPorProducto (tenant_id, producto_id, lista_precio_id, precio) VALUES
(1, 1, 1, 18.50),
(1, 2, 1, 12.00);

-- Descuentos por cantidad
INSERT INTO DescuentosPorCantidad (tenant_id, producto_id, cantidad_minima, descuento_porcentaje, tipo_aplicacion) VALUES
(1, 1, 10, 5.00, 'Producto'),
(1, 2, 20, 10.00, 'Producto');

-- Promociones
INSERT INTO Promociones (tenant_id, nombre, descripcion, producto_id, descuento_porcentaje, fecha_inicio, fecha_fin, activo) VALUES
(1, 'Promo Leche Julio', 'Descuento especial por temporada', 1, 7.50, '2025-07-01', '2025-07-31', TRUE);
